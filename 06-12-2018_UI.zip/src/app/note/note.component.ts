import { Component, OnInit, Input,ViewChild } from '@angular/core';
import { Note } from '../note';
import { RouterService} from '../services/router.service';
import {MatChipInputEvent} from '@angular/material';
import { Category } from '../category';
import { Reminder } from '../reminder';
import { HomeComponent } from '../home/home.component';


@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {


  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;

  @Input() note: Note;  
  
  constructor(private routerService: RouterService) {
  
  }

  openEditView() {
	  console.log('openEditView123 '+this.note.noteId);
     this.routerService.routeToEditNoteView(this.note.noteId);
    }

  ngOnInit() 
  {
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if (input) {
      input.value = '';
    }
  }

  removeCategories(note: Note, category: Category): void 
  {
    let index = this.note.categories.indexOf(category);
    console.log('removing category '+index);
    this.note.categories.splice(index, 1);   
}

removeReminders(note: Note, reminder: Reminder): void {
  let index = this.note.reminders.indexOf(reminder);

console.log('removing category '+index);

  this.note.reminders.splice(index, 1);
}



}
